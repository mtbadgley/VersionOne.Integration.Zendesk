# VersionOne Integration for Zendesk

This integration allows you to create VersionOne defects from Zendesk tickets. 

If you are interested in contributing to this project, please contact [Acey Bunch](mailto:acey.bunch@versionone.com), Partner Integration Specialist at [VersionOne](http://www.versionone.com).




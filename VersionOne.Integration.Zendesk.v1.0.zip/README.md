# VersionOne Zendesk Integration

This integration allows you to create VersionOne defects from Zendesk tickets. 

For more information contact [Acey Bunch](mailto:acey.bunch@versionone.com), Partner Integration Specialist at [VersionOne](http://www.versionone.com).


